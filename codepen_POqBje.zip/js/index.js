$(document).ready(function(){
   
  var o2 = $('#c2')
  o2.owlCarousel({
    items:1,
    singleItem:true,
    loop:true,
    margin:10,    
    //dots:false,
    pagination:false,
    navigation :true,
    touchDrag: true,
    mouseDrag: false,
    afterMove: function (elem) {
      var current = this.currentItem;
      o1.trigger('owl.goTo',current);
    }
});
  
    var o1 = $('#c1');
    o1.owlCarousel({
    items:1,
    singleItem:true,
    loop:true,
    margin:10,    
    //dots:false,
    pagination:false,
    navigation :true,
    touchDrag: true,
    mouseDrag: false,
    afterMove: function (elem) {
      var current = this.currentItem;
      o2.trigger('owl.goTo',current);
    }
});
  


  
});